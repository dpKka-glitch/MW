import React from "react";

export default function Contacts() {
  return <div>Contacts</div>;
}
