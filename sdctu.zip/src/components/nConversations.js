import React, { useRef } from "react";

import { Modal, Form } from "react-bootstrap";
import { Button } from "shards-react";

export default function NewConversation({ closeModal }) {
  return <h2> Hello </h2>;
}
